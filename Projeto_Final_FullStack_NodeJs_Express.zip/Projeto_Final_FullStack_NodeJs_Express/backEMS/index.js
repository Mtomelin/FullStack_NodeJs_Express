const express  = require('express')
const cors = require('cors')
const app = express()

const pacienteRoutes = require('./routes/pacienteRoutes')
const especialidadeRoutes = require('./routes/especialidadeRoutes')

const host = '127.0.0.1'
const port = 3333

app.use(cors("http://localhost:3000/pacientes"))
app.use(express.json())
app.use('/pacientes',pacienteRoutes)
app.use('/especialidades',especialidadeRoutes)

app.listen(port, host,()=>{
    console.log(`Server running at http://${host}:${port}`)
})