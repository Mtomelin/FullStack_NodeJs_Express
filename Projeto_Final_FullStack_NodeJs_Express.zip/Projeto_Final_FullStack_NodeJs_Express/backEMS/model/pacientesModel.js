const {Validator} = require('jsonschema')
const { especialidades } = require('../controller/especialidadeController')
const validator = new Validator()

const pacienteSchema = {    
    type: "object",
    properties: {
        id: {type: 'string'},
        name: {type: 'string'},
        age: {type: 'number', minimum :18},
        email: {type:'string'},
        especialidades:{type:'string'}           
    },
    "required": ['name','age','email','especialidades']
  }

  const validateDataPaciente = (e)=>{
    return validator.validate(e,pacienteSchema)
  }

  module.exports= {validateDataPaciente}
