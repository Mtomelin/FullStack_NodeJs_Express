const express = require('express')
const router = express.Router()

const especialidadeController = require('../controller/especialidadeController')

router.get('/', especialidadeController.getEspecialidades)
router.post('/add',especialidadeController.addEspecialidades)
router.delete('/delete',especialidadeController.removeEspecialidades)

module.exports= router