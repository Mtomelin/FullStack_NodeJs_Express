const express = require('express')
const router = express.Router()

//const pacienteController = require('../controller/pacienteController')
const pacienteController = require('../controller/pacienteFileController') 

router.get('/',pacienteController.getPacientes)

router.post('/add',pacienteController.addPacientes)

router.put('/:id',pacienteController.updatePacientes )

router.delete('/:id',pacienteController.removePacientes )

module.exports= router