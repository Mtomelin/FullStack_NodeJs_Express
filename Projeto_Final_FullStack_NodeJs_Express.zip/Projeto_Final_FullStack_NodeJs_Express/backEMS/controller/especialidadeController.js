let especialidades = ['Cardiologia','Neurologia','Pediatria','Dermatologia','Ortopedia','Oftalmologia']


const getEspecialidades = (req,res)=>{
    res.status(200).json(especialidades)
}

const addEspecialidades = (req,res)=>{
    const especialidade = req.body
    especialidades.push(especialidade.especialidade)
    res.status(200).json(especialidades)
}

const removeEspecialidades = (req,res)=>{
    const especialidade = req.body.especialidade
    console.log(especialidade)
    const index = especialidades.findIndex((d)=>d ===especialidade)

    if(index === -1)
    {
        return res.status(404).json({message:'Especialidade nao encontrada'})
    }
    especialidades.splice(index,1)
    res.status(200).json({message:'Especialidade Deletada'})  
   
}

module.exports={getEspecialidades,addEspecialidades,removeEspecialidades}