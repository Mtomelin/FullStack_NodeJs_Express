const {v4:uuidv4} = require('uuid')
const {especialidade, especialidades} = require ('./especialidadeController')
const {validateDataPaciente} = require('../model/pacientesModel')

const fs = require('fs')

//GET
function getPacientesPromise()
{
    return new Promise((resolve, reject) => {        
        fs.readFile('../backEMS/model/pacientes.json', 'utf8', (err, data) => {
          if (err) {
            reject(err)
          } 
          else {            
            let pacientes = JSON.parse(data)            
            resolve(pacientes)
          }
        })
    })
}
const getPacientes = (req,res)=>{
    getPacientesPromise()
    .then(pacientes => res.status(200).json(pacientes))
    .catch(err => res.status(500).send(err.message));
}  

//POST
function addPacientesPromise(paciente) 
{
  return new Promise((resolve, reject) => {      
    fs.readFile('../backEMS/model/pacientes.json', 'utf8', (err, data) => {
      if (err) {
        reject(err);
      } 
      else {    
                
        let pacientes = JSON.parse(data)   

        if(pacientes.some(e=>e.email===paciente.email))
        {
            reject(new Error('Email ja existente'))                  
        }

        const id = uuidv4()         
        const pacienteNew = { id, ...paciente }  
        
        pacientes.push(pacienteNew)  
        
        fs.writeFile('../backEMS/model/pacientes.json', JSON.stringify(pacientes), (err) => {
          if (err) {
            reject(err);
          } else {
            resolve(pacienteNew);
          }
        })
      }
    })
  })
}

const addPacientes = (req,res)=>{
    const paciente = req.body

    const validResult = validateDataPaciente(paciente)
       
    if(!validResult.valid)
    {
      return res.status(400).json({message:'Dados de paciente invalidos', errors : validResult.errors})
    }    

    if(!especialidades.includes(paciente.especialidade)) 
    {
      return res.status(404).json({message:'Especialidade Invalida'})
    }

    addPacientePromise(paciente)
    .then(pacienteNew => res.status(200).json(pacienteNew))
    .catch(err => res.status(500).send(err.message))
}  


//PUT/PATCH
function updatePacientePromise(id,paciente) 
{
  return new Promise((resolve, reject) => {      
    fs.readFile('../backEMS/model/pacientes.json', 'utf8', (err, data) => {
      if (err) {
        reject(err)
      } else {
        
        let pacientes = JSON.parse(data)  
        
        const index = pacientes.findIndex((e) => e.id === id)

        if (index === -1) {
          reject(new Error('Paciente nao encontrado'))
        } 
        else 
        {
          
          const pacienteUpdate = { ...pacientes[index], ...pacientes, email: pacientes[index].email }  
          
          pacientes[index] = pacienteUpdate  
          
          fs.writeFile('../backEMS/model/pacientes.json', JSON.stringify(pacientes), (err) => {
            if (err) {
              reject(err)
            } else {
              resolve(pacienteUpdate)
            }
          })
        }
      }
    })
  })
}
  
const updatePacientes = (req,res) =>{
  const id = req.params.id
  const paciente = req.body
  updatePacientesPromise(id,paciente) 
  .then(pacienteUpdate => res.status(200).json(pacienteUpdate))
  .catch(err => res.status(500).send(err.message))

}

//DELETE
function removePacientesPromise(id) 
{
  return new Promise((resolve, reject) => {
    fs.readFile('../backEMS/model/pacientes.json', 'utf8', (err, data) => {
      if (err) {
        reject(err)
      } 
      else {
        
          const pacientes = JSON.parse(data)
          
          const index = pacientes.findIndex(e => e.id === id)

          if (index === -1) {
            reject(new Error('Paciente nao encontrado'))
          } 
          else {
            
            pacientes.splice(index, 1)
            
            fs.writeFile('../backEMS/model/pacientes.json', JSON.stringify(pacientes), err => {
              if (err) {
                reject(err)
              } else {
                resolve()
              }
            })
          }       
      }
    })
  })
}

const removePacientes = (req,res)=>{      
    const id = req.params.id
    removePacientesPromise(id)
    .then(() => res.status(200).json({message:'Paciente Deletado'}))
    .catch(err => res.status(500).send(err.message))
}


module.exports = {getPacientes,addPacientes,updatePacientes, removePacientes}