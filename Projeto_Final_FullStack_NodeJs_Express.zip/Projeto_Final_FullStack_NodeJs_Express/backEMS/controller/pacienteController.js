const {v4:uuidv4} = require('uuid')
const {especialidades} = require ('./especialidadeController')
const {validateDataPaciente} = require('../model/pacientesModel')

let pacientes = []

const getPacientes = (req,res)=>{
    res.status(200).json(pacientes)
}

const addPacientes = (req,res)=>{
    const paciente = req.body
    try{
       const validResult = validateDataPaciente(paciente)
       
       if(!validResult.valid)
       {
            return res.status(400).json({message:'Dados de Paciente Invalidos', errors : validResult.errors})
       }

       if(pacientes.some(e=>e.email===req.body.email))
       {
          return res.status(400).json({message:'Email ja existente'})         
       }

       if(!especialidades.includes(paciente.especialidade)) 
       {
        return res.status(404).json({message:'Especialidade Invalida'})
       }

        paciente.id = uuidv4()
        pacientes.push(paciente)
        res.status(200).json(paciente)
    }
    catch(err)
    {
        console.error(err)
        res.status(500).json({message:'Server Error'})
    }
    
}

const updatePacientes = (req,res)=>{
    const id = req.params.id
    const paciente = req.body
    
    try{
        const index = pacientes.findIndex((e)=>e.id===id)
        if(index === -1)
        {
            return res.status(404).json({message:'Paciente nao Encontrado'})
        }
        pacientes[index] ={...pacientes[index],... paciente}
        res.status(200).json(pacientes[index])
    }
    catch(err)
    {
        console.error(err)
        res.status(500).json({message:'Erro no Servidor'})
    }
}

const removePacientes = (req,res)=>{      
    const id = req.params.id
    try{
        const index = pacientes.findIndex((e)=>e.id===id)
        if(index === -1)
        {
            return res.status(404).json({message:'Paciente nao Encontrado'})
        }
        pacientes.splice(index,1)
        res.status(200).json({message:'Paciente Deletado'})
    }
    catch(err)
    {
        console.error(err)
        res.status(500).json({message:'Erro no Servidor'})
    }
}

module.exports = {getPacientes,addPacientes,updatePacientes,removePacientes}